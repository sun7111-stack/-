﻿/**
 * 碳融智核 - 3D 碳排放数字孪生监控大屏 (Three.js 引擎)
 * 赛道评委高分炫技点：WebGL 直接渲染、粒子系统、光效
 */
let scene, camera, renderer, controls;
let particles = [];
let emissiveRate = 0.5; // 基础排放扩散率
let animationId;
let factoryGroup;

// 1. 初始化 3D 舞台
function init3DTwin() {
    const container = document.getElementById('factory3dContainer');
    if (!container || scene) return; // 避免重复初始化

    // 场景
    scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x050510, 0.015);

    // 相机
    camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 1, 1000);
    camera.position.set(30, 25, 40);

    // 渲染器 (抗锯齿，背景透明度)
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // 控制器
    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 1.0;
    controls.maxPolarAngle = Math.PI / 2 - 0.05; // 不允许钻入地下

    addLights();
    addEnvironment();
    buildFactory();
    initParticleSystem();

    // 绑定窗口大小调整
    window.addEventListener('resize', onWindowResize, false);
    
    // 开始推流渲染
    animate();
}

function addLights() {
    const ambientLight = new THREE.AmbientLight(0x222233);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x00f8ff, 0.8);
    dirLight.position.set(20, 50, 20);
    dirLight.castShadow = true;
    scene.add(dirLight);

    const pointLight = new THREE.PointLight(0xff4400, 1.5, 50);
    pointLight.position.set(-10, 10, -10);
    scene.add(pointLight);
}

function addEnvironment() {
    // 充满赛博朋克感的网格线
    const gridHelper = new THREE.GridHelper(100, 40, 0x0dcaf0, 0x333333);
    scene.add(gridHelper);

    // 地面材质
    const planeGeo = new THREE.PlaneGeometry(100, 100);
    const planeMat = new THREE.MeshPhongMaterial({ color: 0x0a0a0a, depthWrite: false });
    const plane = new THREE.Mesh(planeGeo, planeMat);
    plane.rotation.x = -Math.PI / 2;
    plane.receiveShadow = true;
    scene.add(plane);
}

function buildFactory() {
    factoryGroup = new THREE.Group();
    
    // 基础工业风格材质
    const buildingMat = new THREE.MeshStandardMaterial({ 
        color: 0x223344, 
        roughness: 0.3,
        metalness: 0.8
    });

    const glowMat = new THREE.MeshBasicMaterial({ color: 0x0dcaf0 });

    // 主厂房
    const mainBldg = new THREE.Mesh(new THREE.BoxGeometry(15, 6, 20), buildingMat);
    mainBldg.position.set(0, 3, 0);
    mainBldg.castShadow = true;
    mainBldg.receiveShadow = true;
    factoryGroup.add(mainBldg);

    // 侧边仓库
    const sideBldg = new THREE.Mesh(new THREE.BoxGeometry(10, 5, 10), buildingMat);
    sideBldg.position.set(13, 2.5, -5);
    sideBldg.castShadow = true;
    factoryGroup.add(sideBldg);

    // 装饰霓虹线条 (模拟数据流光带)
    const neonGeo = new THREE.BoxGeometry(15.2, 0.2, 20.2);
    const neon = new THREE.Mesh(neonGeo, glowMat);
    neon.position.set(0, 5.8, 0);
    factoryGroup.add(neon);

    // 大烟囱 (排放口)
    const chimney = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 2, 12, 16), buildingMat);
    chimney.position.set(-5, 6, -5);
    chimney.castShadow = true;
    factoryGroup.add(chimney);

    // 烟囱口红标
    const chimRing = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.6, 0.5, 16), new THREE.MeshBasicMaterial({color: 0xff0000}));
    chimRing.position.set(-5, 11.8, -5);
    factoryGroup.add(chimRing);

    scene.add(factoryGroup);
}

// 粒子系统：代表碳排放量
let particleSystem;
function initParticleSystem() {
    const pCount = 500;
    const pGeo = new THREE.BufferGeometry();
    const pMat = new THREE.PointsMaterial({
        color: 0xffaa00,
        size: 0.8,
        transparent: true,
        opacity: 0.6,
        blending: THREE.AdditiveBlending
    });

    const positions = new Float32Array(pCount * 3);
    const velocities = [];

    // 初始化为隐藏状态 (全在地底)
    for (let i = 0; i < pCount; i++) {
        positions[i*3] = -5 + (Math.random() - 0.5); // X (烟囱位置附近)
        positions[i*3+1] = -10; // Y 地下
        positions[i*3+2] = -5 + (Math.random() - 0.5); // Z

        velocities.push({
            vX: (Math.random() - 0.5) * 0.1,
            vY: 0.1 + Math.random() * 0.2, // 向上飘的初始速度
            vZ: (Math.random() - 0.5) * 0.1
        });
    }

    pGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleSystem = new THREE.Points(pGeo, pMat);
    particleSystem.velocities = velocities;
    scene.add(particleSystem);
}

// 供外部触发以更新孪生的碳排放速率表现
window.updateTwinEmissions = function(totalTons) {
    // 根据总吨数映射粒子速度和颜色预警
    emissiveRate = Math.max(0.2, Math.min(totalTons / 5, 3.0));
    
    const uiRate = (totalTons * 1000 / (365 * 24 * 3600)).toFixed(4); // 模拟每秒排出千克
    document.getElementById('twinEmissionsRate').innerText = uiRate;

    // 超过一定阀值报警，变成红色
    if(emissiveRate > 2.0) {
        particleSystem.material.color.setHex(0xff3300); // 危险红
        document.getElementById('twinEmissionsRate').className = "text-danger fw-bold fs-5 flash-status";
    } else {
        particleSystem.material.color.setHex(0xffaa00); // 预警橙
        document.getElementById('twinEmissionsRate').className = "text-warning fw-bold fs-5";
    }
}

function updateParticles() {
    if (!particleSystem) return;
    const positions = particleSystem.geometry.attributes.position.array;
    
    // 我们限制活动粒子的数量以配合 emissiveRate
    let activeLimit = Math.floor(positions.length / 3 * (emissiveRate / 3.0));
    
    for (let i = 0; i < positions.length / 3; i++) {
        let y = positions[i*3+1];
        
        if (i < activeLimit) {
            // 如果粒子已经飞太高，重置回烟囱口
            if (y > 25 || y < 11) {
                positions[i*3] = -5 + (Math.random() - 0.5);
                positions[i*3+1] = 12; // 烟囱高度
                positions[i*3+2] = -5 + (Math.random() - 0.5);
                
                // 给一个向上的随机初速度
                particleSystem.velocities[i].vY = 0.05 + Math.random() * 0.1 * emissiveRate;
            }
            
            // 更新粒子位置 (模拟风和扩散)
            positions[i*3] += particleSystem.velocities[i].vX * emissiveRate;
            positions[i*3+1] += particleSystem.velocities[i].vY;
            positions[i*3+2] += particleSystem.velocities[i].vZ * emissiveRate;
        } else {
            // 降低活跃率时把多余粒子藏掉
            positions[i*3+1] = -10;
        }
    }
    particleSystem.geometry.attributes.position.needsUpdate = true;
}

function onWindowResize() {
    const container = document.getElementById('factory3dContainer');
    if (!container || !camera || !renderer) return;
    camera.aspect = container.clientWidth / container.clientHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(container.clientWidth, container.clientHeight);
}

function animate() {
    animationId = requestAnimationFrame(animate);
    controls.update();
    updateParticles();
    renderer.render(scene, camera);
}
